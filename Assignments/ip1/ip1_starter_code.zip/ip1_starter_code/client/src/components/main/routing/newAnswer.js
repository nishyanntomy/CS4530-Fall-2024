import PageClass from ".";
import NewAnswer from "../newAnswer";

export default class NewAnswerPageClass extends PageClass {
    getContent() {
        console.log(this);
        return <NewAnswer qid={this.qid} handleAnswer={this.handleAnswer} />;
    }

    getSelected() {
        return "";
    }
}