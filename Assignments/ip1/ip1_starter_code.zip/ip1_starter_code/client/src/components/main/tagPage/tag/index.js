import "./index.css";
import { getTagByName } from "../../../../services/tagService";
import { useEffect, useState } from "react";
const Tag = ({ t, clickTag }) => {
    const [tag, setTag] = useState({});
    useEffect(() => {
        const fetchData = async () => {
            const res = await getTagByName(t.name);
            setTag(res || {name: "Error", description: "Error"});
        };

        fetchData().catch((e) => console.log(e));
    }, []);
    
    return (
        <div
            className="tagNode"
            onClick={() => {
                clickTag(tag.name);
            }}
        >
            <div className="tagName">{tag.name}</div>
            <div className="tagDescription">{tag.description}</div>
            <div>{t.qcnt} questions</div>
        </div>
    );
};

export default Tag;
