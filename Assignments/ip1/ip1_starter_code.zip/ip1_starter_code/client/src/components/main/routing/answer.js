import PageClass from ".";
import AnswerPage from "../answerPage";

export default class AnswerPageClass extends PageClass {
    getContent() {
        console.log(this);
        return (
            <AnswerPage
                qid={this.qid}
                handleNewQuestion={this.handleNewQuestion}
                handleNewAnswer={this.handleNewAnswer}
            />
        );
    }

    getSelected() {
        return "";
    }
}