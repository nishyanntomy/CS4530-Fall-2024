import PageClass from '.';
import QuestionPage from "../questionPage";

export default class HomePageClass extends PageClass {
    getContent() {
        return (
            <QuestionPage
                title_text={this.title}
                order={this.questionOrder.toLowerCase()}
                search={this.search}
                setQuestionOrder={this.setQuestionOrder}
                clickTag={this.clickTag}
                handleAnswer={this.handleAnswer}
                handleNewQuestion={this.handleNewQuestion}
            />
        );
    }

    getSelected() {
        return "q";
    }
}