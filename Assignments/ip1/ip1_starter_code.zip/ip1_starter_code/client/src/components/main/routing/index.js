export default class PageClass {
    constructor(search, title, setQuesitonPage, 
            questionOrder, setQuestionOrder, qid, 
            handleQuestions, handleTags,
            handleAnswer, clickTag,
            handleNewQuestion, handleNewAnswer
        ) {
            this.search = search;
            this.title = title;
            this.setQuesitonPage = setQuesitonPage;
            this.questionOrder = questionOrder;
            this.setQuestionOrder = setQuestionOrder;
            this.qid = qid;
            this.handleQuestions = handleQuestions;
            this.handleTags = handleTags;
            this.handleAnswer = handleAnswer;
            this.clickTag = clickTag;
            this.handleNewQuestion = handleNewQuestion;
            this.handleNewAnswer = handleNewAnswer;
        }
    
        getContent() {
            throw new Error("Method 'getContent()' must be implemented.");
        }

        getSelected() {
            throw new Error("Method 'getSelected()' must be implemented.");
        }
}