import PageClass from ".";
import TagPage from "../tagPage";

export default class TagPageClass extends PageClass {
    getContent() {
        return (
            <TagPage
                    clickTag={this.clickTag}
                    handleNewQuestion={this.handleNewQuestion}
                />
        );
    }

    getSelected() {
        return "t";
    }
}