import PageClass from ".";
import NewQuestion from "../newQuestion";

export default class NewQuestionPageClass extends PageClass {
    getContent() {
        console.log(this);
        return <NewQuestion handleQuestions={this.handleQuestions} />;
    }

    getSelected() {
        return "";
    }
}