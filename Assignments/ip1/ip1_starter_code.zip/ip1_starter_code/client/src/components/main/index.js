import "./index.css";
import { useState } from "react";
import SideBarNav from "./sideBarNav";
import HomePageClass from "./routing/home";
import TagPageClass from "./routing/tag";
import AnswerPageClass from "./routing/answer";
import NewQuestionPageClass from "./routing/newQuestion";
import NewAnswerPageClass from "./routing/newAnswer";

const Main = ({ search = "", title, setQuesitonPage }) => {
    const [questionOrder, setQuestionOrder] = useState("newest");
    const [qid, setQid] = useState("");

    const handleQuestions = () => {
        setQuesitonPage();
        setPageInstance(new HomePageClass(search, title, setQuesitonPage,
            questionOrder, setQuestionOrder, qid,
            handleQuestions, handleTags, handleAnswer,
            clickTag, handleNewQuestion, handleNewAnswer
        ));
    };

    const handleTags = () => {
        setPageInstance(new TagPageClass(search, title, setQuesitonPage,
            questionOrder, setQuestionOrder, qid,
            handleQuestions, handleTags, handleAnswer,
            clickTag, handleNewQuestion, handleNewAnswer
        ));
    };

    const handleAnswer = (qid) => {
        setQid(qid);
        setPageInstance(new AnswerPageClass(search, title, setQuesitonPage,
            questionOrder, setQuestionOrder, qid,
            handleQuestions, handleTags, handleAnswer,
            clickTag, handleNewQuestion, handleNewAnswer
        ));
    };

    const clickTag = (tname) => {
        setQuesitonPage("[" + tname + "]", tname);
        setPageInstance(new HomePageClass(search, title, setQuesitonPage,
            questionOrder, setQuestionOrder, qid,
            handleQuestions, handleTags, handleAnswer,
            clickTag, handleNewQuestion, handleNewAnswer
        ));
    };

    const handleNewQuestion = () => {
        setPageInstance(new NewQuestionPageClass(search, title, setQuesitonPage,
            questionOrder, setQuestionOrder, qid,
            handleQuestions, handleTags, handleAnswer,
            clickTag, handleNewQuestion, handleNewAnswer
        ));
    };

    const handleNewAnswer = () => {
        console.log("handleNewAnswer");
        console.log(qid);
        setPageInstance(new NewAnswerPageClass(search, title, setQuesitonPage,
            questionOrder, setQuestionOrder, qid,
            handleQuestions, handleTags, handleAnswer,
            clickTag, handleNewQuestion, handleNewAnswer
        ));
    };

    const [pageInstance, setPageInstance] = useState(new HomePageClass(search, title, setQuesitonPage,
        questionOrder, setQuestionOrder, qid,
        handleQuestions, handleTags, handleAnswer,
        clickTag, handleNewQuestion, handleNewAnswer
    ));

    pageInstance.search = search;
    pageInstance.questionOrder = questionOrder;
    pageInstance.qid = qid;

    return (
        <div id="main" className="main">
            <SideBarNav
                selected={pageInstance.getSelected()}
                handleQuestions={handleQuestions}
                handleTags={handleTags}
            />
            <div id="right_main" className="right_main">
                {pageInstance.getContent()}
            </div>
        </div>
    );
};

export default Main;
