import React, { useState, useEffect } from 'react';
import { downvoteQuestion, getQuestionById, upvoteQuestion } from '../../../services/questionService';
import './index.css';

const VoteComponent = ({ question, username }) => {
    const [count, setCount] = useState(0);
    const [voted, setVoted] = useState(0); // 0 for not voted, 1 for upvote, -1 for downvote

    const getVoteValue = () => {
        if (username && question?.up_votes?.includes(username)) {
            return 1;
        } else if (username && question?.down_votes?.includes(username)) {
            return -1;
        } else return 0;
    }

    useEffect(() => {
        setCount((question.up_votes || []).length - (question.down_votes || []).length);

        // Fetch and set voteValue once question and username are available
        const fetchVoteValue = async () => {
            const voteValue = await getVoteValue();
            setVoted(voteValue);
        };
        fetchVoteValue();
    }, [question, username]);

    useEffect(() => {
        setCount((question.up_votes || []).length - (question.down_votes || []).length);
    }, [question]);

    const handleVote = async (type) => {
        try {
            if (type === 'upvote' && voted !== 1) {
                await upvoteQuestion(question._id, username);
                setCount(count + (voted === -1 ? 2 : 1));
                setVoted(1);
            } else if (type === 'downvote' && voted !== -1) {
                await downvoteQuestion(question._id, username);
                setCount(count - (voted === 1 ? 2 : 1));
                setVoted(-1);
            } else if ((type === 'upvote' && voted === 1) || (type === 'downvote' && voted === -1)) {
                // Cancel vote
                if (type === 'upvote') {
                    await upvoteQuestion(question._id, username);
                } else {
                    await downvoteQuestion(question._id, username);
                }
                setCount(count - voted);
                setVoted(0);
            } else if ((type === 'upvote' && voted === -1) || (type === 'downvote' && voted === 1)) {
                // Change vote
                if (type === 'upvote') {
                    await upvoteQuestion(question._id, username);
                } else {
                    await downvoteQuestion(question._id, username);
                }
                setCount(count + (type === 'upvote' ? 2 : -2));
                setVoted(type === 'upvote' ? 1 : -1);
            }
            await getQuestionById(question._id);
        } catch (error) {
            console.error('Error:', error);
            // Handle error, e.g., show error message to the user
        }
    };

    return (
        <div className="vote-container">
            <button
                className={`vote-button ${voted === 1 ? 'vote-button-upvoted' : ''}`}
                onClick={() => handleVote('upvote')}
            >
                Upvote
            </button>
            <button
                className={`vote-button ${voted === -1 ? 'vote-button-downvoted' : ''}`}
                onClick={() => handleVote('downvote')}
            >
                Downvote
            </button>
            <span className="vote-count">{count}</span>
        </div>
    );
};

export default VoteComponent;
