import { REACT_APP_API_URL, api } from "./config";

const TAG_API_URL = `${REACT_APP_API_URL}/tag`;



const getTagsWithQuestionNumber = async () => {
    const res = await api.get(`${TAG_API_URL}/getTagsWithQuestionNumber`);
    if(res.status !== 200) {
        throw new Error("Error when fetching tags with question number");
    }
    return res.data;
};

// New function to get a tag by name
const getTagByName = async (name) => {
    const res = await api.get(`${TAG_API_URL}/getTagByName/${name}`); // Using the name parameter in the URL
    if (res.status !== 200) {
        throw new Error(`Error when fetching tag: ${name}`);
    }
    return res.data; // Return the tag data
};

export { getTagsWithQuestionNumber, getTagByName };
