# CS4530: Fundamentals of Software Engineering

## Service-oriented Architecture with Node.js, Express, and Mongoose

#### Fall 2024


## Introduction

This project implements a RESTful web service using Node.js, Express, and MongoDB with Mongoose.
As RESTful services are stateless, they must interact with a
database service to help them persist and manage the application’s data.

The server application is built using the Node.js platform to implement a RESTful web service. By utilizing Node.js, JavaScript is used consistently across both the client and server. The Express framework is employed to define web services that align with the HTTP protocol specifications. MongoDB serves as the back-end database, storing data that persists across user sessions. Mongoose, an ORM/ODM framework, manages the interaction between the server and the underlying database, bridging the differences between MongoDB and the Node.js/Express stack. On the front end, the React library is used to render dynamic web content, allowing the design of the application as reusable components.


## Getting Started

We use MongoDB as the NoSQL database to store data related to this application. Follow
the [instructions in the official MongoDB documentation](https://www.mongodb.com/docs/manual/administration/install-community/) to install the free community edition.
On Windows, you should unselect the _“MongoDB as a Service”_ option to complete the
installation. After you install it, follow the instructions to start MongoDB as a **background
service**. The Mongo Shell ( **mongosh** ) should also have been installed when you installed
MongoDB. If it wasn’t, then follow the instructions [here](https://www.mongodb.com/docs/mongodb-shell/install/#std-label-mdb-shell-install). The Mongo Shell provides a command
line interface that is used to interact with the databases in MongoDB. If _mongosh_ is successfully
installed, then the command **mongosh** should connect to the local instance of MongoDB on
your system and open an interpreter where we can type commands to interact with MongoDB.
Try the command **show dbs;** you should see a list of existing databases in your local instance.
**Note that by default, the MongoDB service will run on** **_127.0.0.1_** **(localhost), port** **_27017_****. It is
recommended that you do not change these settings.**

Install [Node.js](https://nodejs.org/en/download/package-manager). We use this to manage React and the packages needed to run our server.
When you install Node.js, it will come with the **npm** package manager, which will also get
installed. We will use **npm** to install dependencies and also to start the react application.

**Download/clone your personal GitHub repository**. The repository has a _server_ and _client_
directory. Each directory has the package.json and package-lock.json files which list the
dependencies of the _server_ and _client_ applications respectively. Use the following commands to
install all dependencies from the project’s root:

_$ cd client/_

_$ npm install_

_$ cd server/_

_$ npm install_

_$ cd testing_

_$ npm install_

A successful install should install the packages for mongoose, express, jest, eslint, axios, cors,
and nodemon at the very least. A brief description of the relevant packages with links to their
documentation is given below.

The [express](https://expressjs.com/) framework to write server-side code. Install express in the server directory using
the command **npm install express** , if the above installation process failed. If you don’t yet


understand how to use express, start with the examples discussed in class. For more detailed
guidance look at the official [Express documentation](https://expressjs.com/en/guide/routing.html).
The [mongoose data modeling library](https://mongoosejs.com/docs/index.html). Mongoose will help us connect with a MongoDB instance
and define operations to manage and manipulate the data according to the needs of our
application. Install it in the server directory using **npm install mongoose** , if the previous
installation process failed.

The [nodemon](https://www.npmjs.com/package/nodemon) process manager, so we don’t have to restart the server every time we save
changes to our server. Install it in the server directory using
**npm install nodemon** , if not already installed. Alternatively, if the local install does not work,
you can install nodemon globally using the command **npm install -g nodemon**. This is a good
option for nodemon since it can be used across multiple node projects. To run the server using
nodemon use the command **nodemon server/server.js** instead of **node server/server.js**.

We use the [axios](https://axios-http.com/docs/intro) library to send HTTP requests to our server from our client application.
Install it in the client directory using **npm install axios** , if
the previous installation steps did not work.

We use the [cors](https://www.npmjs.com/package/cors) middleware to enable CORS to enable seamless connection between the
client and the server. The current cors configuration allows all
connections to the server for convenience. This is fine for a development environment. In a
production environment where the application is deployed on a cloud service, the CORS policy
needs to be specified more strictly. Read more about CORS [https://developer.mozilla.org/en-
US/docs/Web/HTTP/CORS](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS).

## Client/Server Application Architecture

The repository is structured as a client/server application. It has 2 directories –
**server** and **client**. The **server** directory contains a schema of the data model in the
**models/schema** directory in files _answers.js_ , _questions.js_ , and _tags.js_. These files are empty.
You should fill them up with the appropriate schema definition for each corresponding
document in our MongoDB collection. A class diagram for the expected schema definition is
shown below:

![Class Diagram](class-diagram.png)


**Once the schema is defined, you can run the script in server/populate_db.js using node to
verify that your document schema is defined correctly**. Read the instructions at the top of the
script to see how to run it. If this script throws an error, you will know something is wrong with
the schema definition and must fix it. Make sure the mongod process is up and running before
you execute the script.

The **server/server.js** file is the main server script. You should run this script in node to start
your server using the command **node server/server.js**. On running the script, a server should
start in [**https://locahost:8000**](https://locahost:8000/). Further, the server should connect to a running instance of
MongoDB on server launch. The MongoDB instance should run with default settings, that is,
**mongodb://127.0.0.1:27017/**. **The database name must be fake_so**.
When the server is terminated (using CTRL+C), the database should also be disconnected and
the message **“Server closed. Database instance disconnected”** should be displayed.

The **client** directory has the same structure as that of the React application you made in
homework 2. You don’t need to change anything in the client code. The client code uses Axios
to send HTTP method requests to the server. You should review the client code to understand
how axios sends requests and and the response from the server is processed.

**Summary of the default host/port settings:**

|                                               |                                                                               |
|:---------------------------------|:--------------------------------------------------------|
| Client Instance                      | [https://localhost:3000/](https://localhost:3000/)  |
| Server Instance                     | [https://localhost:8000/](https://localhost:8000/)  |  
| Database Instance                 | mongodb://127.0.0.1:27017/fake_so                    |

## Testing

We are using two types of testing in this project -- unit testing and e2e integration testing.

The unit tests are written in Jest, a popular testing library in JavaScript. Skim through the Jest
tutorial [here](https://jestjs.io/docs/getting-started) before attempting to write any code. The e2e integration tests are the familiar
Cypress tests which we have used before.

The tests in _server/tests_ are Jest tests. Their purpose is to verify the correctness of the
JavaScript functions and web services defined in the server. A brief description of the tests is as
follows:

- _newAnswer.test.js_ : The tests here are used to verify that the expected response is
    received when a request is sent to the server’s defined URI to create a new answer for a
    question.
- _newQuestion.test.js_ : The tests here are used to verify that the expected response is
    received when a request is sent to the server’s defined URIs view all questions, view a
    question, and create a new question.
- _tags.test.js_ : The tests here are used to verify that the expected response is received
    when a request is sent to the server’s defined URI view all tags and the number of
    questions for each tag.
- _Question.test.js:_ The tests here are used to verify the functions defined in
    _utils/question.js_.

The Cypress e2e tests are in _testing/cypress/e2e_. We are interacting
with a server that uses a persistent data store to read and write data. However, to write
effective tests that verify the individual features in our application, we need to ensure that
before every test, we start with a new database, and after every test the database is wiped
clean. To this end, the cypress tests are configured with a _beforeEach_ and _afterEach_ construct
to setup and destroy the backend database accordingly.

**Running the tests**

Use the following command to run the Jest unit tests:

_$ cd server/_

_$ npm test tests/`<name-of-test-file>`_

_$ npm test_ (to run all tests)


Use the following commands to open the Cypress tests in a Cypress controlled browser:


_$ cd client/_

_$ npm start_

_$ cd server/_

_$ node server.js_

_$ cd testing/_

_$ npx cypress open_

Use the following commands to run the Cypress tests in headless mode:

_$ cd client/_

_$ npm start_

_$ cd server/_

_$ node server.js_

_$ cd testing/_

_$ npx cypress run --spec `</path/to/e2e/tests>`_


## Recommendations when working on the project


1. Open the client application in a browser and interact with it. While interacting, monitor
    the application tab in the browser’s developer tools. The application tab will give you
    information about the HTTP requests the client sends to the server. The HTTP requests
    will contain URIs in their headers. You can use this information to understand the
    endpoints in the server.
2. Read the Jest tests. The Jests tests list all the endpoints the server should have, and the
    type of HTTP method associated with them. Further, the tests also have information
    about the Mongoose functions that need to be invoked for the service to send a
    successful response.
3. Start by defining the schemas in the server/models/schema directory to ensure the data structure is consistent.
4. Make sure to run all Jest tests. These tests are designed to catch issues early. Once all Jest tests pass, the Cypress tests should also pass, assuming no significant changes have been made to the client’s implementation.



## Useful Resources

1. Mongoose Queries: [https://mongoosejs.com/docs/queries.html](https://mongoosejs.com/docs/queries.html)
2. Mongoose Documents: [https://mongoosejs.com/docs/documents.html](https://mongoosejs.com/docs/documents.html)
3. Jest Basics: [https://jestjs.io/docs/getting-started](https://jestjs.io/docs/getting-started)
4. Mocking in Jest: [https://jestjs.io/docs/mock-functions](https://jestjs.io/docs/mock-functions)
5. Mocking Mongoose functions: [https://github.com/alonronin/mockingoose](https://github.com/alonronin/mockingoose)
6. Express Tutorial: [https://expressjs.com/en/guide/routing.html](https://expressjs.com/en/guide/routing.html)

