import express, { Response } from 'express';
import { Answer, AnswerRequest } from '../types';
import { addAnswerToQuestion, saveAnswer } from '../models/application';

const router = express.Router();


function isRequestValid(req: AnswerRequest): boolean {
    return !!req.body.qid && !!req.body.ans;
}

function isAnswerValid(ans: Answer): boolean {
    return !!ans.text && !!ans.ans_by && !!ans.ans_date_time;
}

// Adding answer
const addAnswer = async (req: AnswerRequest, res: Response): Promise<void> => {
    if (!isRequestValid(req)) {
        res.status(400).send("Invalid request");
        return;
    }
    if(!isAnswerValid(req.body.ans)) {
        res.status(400).send("Invalid answer");
        return;
    }
    const qid = req.body.qid;
    const ansInfo: Answer = req.body.ans;
    try {
        const ansFromDb = await saveAnswer(ansInfo);
        if('error' in ansFromDb) {
            throw new Error(ansFromDb.error as string);
        }
        const status = await addAnswerToQuestion(qid, ansFromDb);
        if(status && 'error' in status) {
            throw new Error(status.error as string);
        }
        res.json(ansFromDb);
    }
    catch(err) {
        res.status(500).send(`Error when adding answer: ${(err as Error).message}`);
    }
};

// add appropriate HTTP verbs and their endpoints to the router.
router.post("/addAnswer", addAnswer);

export default router;
