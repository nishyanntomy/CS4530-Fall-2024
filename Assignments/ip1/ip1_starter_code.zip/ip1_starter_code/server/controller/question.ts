import express, { Response } from 'express';
import { OrderType, Question, FindQuestionRequest, FindQuestionByIdRequest, AddQuestionRequest } from '../types';
import mongoose from 'mongoose';
import { fetchAndIncrementQuestionViewsById, filterQuestionsBySearch, getQuestionsByOrder, getTags, saveQuestion } from '../models/application';

const router = express.Router();
const ObjectId = mongoose.Types.ObjectId;

// To get Questions by Filter
const getQuestionsByFilter = async (req: FindQuestionRequest, res: Response): Promise<void> => {
    const order: OrderType = req.query.order;
    const search: string = req.query.search;
    try {
        let qlist : Question[] = await getQuestionsByOrder(order);
        const resqlist : Question[] = await filterQuestionsBySearch(qlist, search);
        res.json(resqlist);
    } catch (err : unknown) {
        if(err instanceof Error) {
            res.status(500).send(`Error when fetching questions by filter: ${err.message}`);
        }else{
            res.status(500).send(`Error when fetching questions by filter`);
        }
    }
};

// To get Questions by Id
const getQuestionById = async (req: FindQuestionByIdRequest, res: Response) : Promise<void> => {
    const qid = req.params.qid;
    if (!ObjectId.isValid(qid)) {
        res.status(400).send("Invalid ID format");
        return;
    }
    try {
        const q = await fetchAndIncrementQuestionViewsById(qid);
        if(q && !('error' in q)) {
            res.json(q);
            return;
        }
        else {
            throw new Error("Error while fetching question by id");
        }
    }
    catch(err: unknown) {
        if(err instanceof Error) {
            res.status(500).send(`Error when fetching question by id: ${err.message}`);
        }
        else{
            res.status(500).send(`Error when fetching question by id`);
        }
    }
};

// To check if Question body is valid
const isQuestionBodyValid = (question: Question): boolean => {
    return (
        question.title !== undefined && question.title !== "" &&
        question.text !== undefined && question.text !== "" &&
        question.tags !== undefined && question.tags.length > 0 &&
        question.asked_by !== undefined && question.asked_by !== "" &&
        question.ask_date_time !== undefined && question.ask_date_time !== null 
    );
};

// To add Question
const addQuestion = async (req : AddQuestionRequest, res : Response ) : Promise<void> => {
    if (!isQuestionBodyValid(req.body)){
        res.status(400).send("Invalid question body");
        return;
    }
    const question: Question = req.body;
    try {
        question.tags = await getTags(question.tags);
        if(question.tags.length == 0) {
            throw new Error("Invalid tags");
        }
        const result = await saveQuestion(question);
        if ('error' in result) {
            throw new Error(result.error);
        }
        res.json(result);
    }
    catch(err: unknown) {
        if(err instanceof Error) {

            res.status(500).send(`Error when saving question: ${err.message}`);
        }
        else { 
            res.status(500).send(`Error when saving question`);
        }
    }
};

// add appropriate HTTP verbs and their endpoints to the router
router.get("/getQuestion", getQuestionsByFilter);
router.get("/getQuestionById/:qid", getQuestionById);
router.post("/addQuestion", addQuestion);

export default router;
