import { Request } from 'express';
import { ObjectId } from 'mongodb';

export type OrderType = 'newest' | 'unanswered' | 'active';

export interface Answer {
    _id?: ObjectId;
    text: string;
    ans_by: string;
    ans_date_time: Date;
}

export interface AnswerRequest extends Request {
    body: {
        qid: string;
        ans: Answer;
    };
}

export type AnswerResponse = Answer | { error: string };

export interface Tag {
    _id?: ObjectId;
    name: string;
}

export interface Question {
    _id?: ObjectId;
    title: string;
    text: string;
    tags: Tag[];
    asked_by: string;
    ask_date_time: Date;
    answers: Answer[];
    views: number;
}

export type QuestionResponse = Question | { error: string };

export interface FindQuestionRequest extends Request {
    query: {
        order: OrderType;
        search: string;
    };
}

export interface FindQuestionByIdRequest extends Request {
    params: {
        qid: string;
    }
}

export interface AddQuestionRequest extends Request {
    body: Question;
}