import { Schema } from 'mongoose';
import mongoose from 'mongoose';

// Schema for questions
const questionSchema: Schema = new Schema(
    {
        title: {
            type: String,
        },
        text: {
            type: String,
        },
        tags: [{ type: mongoose.Schema.Types.ObjectId, ref: "Tag" }],
        answers: [{ type: mongoose.Schema.Types.ObjectId, ref: "Answer" }],
        asked_by: {
            type: String,
        },
        ask_date_time: {
            type: Date,
        },
        views: {
            type: Number,
            default: 0,
        },
    },
    { collection: "Question" }
);

export default questionSchema;