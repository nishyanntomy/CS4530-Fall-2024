import { Schema } from 'mongoose';

// Schema for answers
const answerSchema: Schema = new Schema(
    {
        text: {
            type: String,
        },
        ans_by: {
            type: String,
        },
        ans_date_time: {
            type: Date,
        },
    },
    { collection: "Answer" }
);

export default answerSchema;
