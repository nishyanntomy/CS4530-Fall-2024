import { Schema } from 'mongoose';

// Schema for tags
const tagSchema: Schema = new Schema(
    {
        name: {
            type: String,
            required: true
        },
    },
    { collection: "Tag" }
);

export default tagSchema;
