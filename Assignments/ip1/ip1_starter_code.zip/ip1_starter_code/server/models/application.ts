/* eslint-disable @typescript-eslint/no-unused-vars */
import { Answer, AnswerResponse, OrderType, Question, QuestionResponse, Tag } from "../types";
import AnswerModel from "./answers";
import QuestionModel from "./questions";
import TagModel from "./tags";
import { ObjectId } from 'mongodb';

export const parseTags = (search: string): string[] => {
    return (search.match(/\[([^\]]+)\]/g) || []).map((word) =>
        word.slice(1, -1)
    );
};

export const parseKeyword = (search: string): string[] => {
    return search.replace(/\[([^\]]+)\]/g, " ").match(/\b\w+\b/g) || [];
};

export const checkTagInQuestion = (q: Question, taglist: string[]): boolean => {
    for (const tagname of taglist) {
        for (const tag of q.tags) {
            if (tagname == tag.name) {
                return true;
            }
        }
    }

    return false;
};

export const checkKeywordInQuestion = (q: Question, keywordlist: string[]): boolean => {
    for (const w of keywordlist) {
        if (q.title.includes(w) || q.text.includes(w)) {
            return true;
        }
    }

    return false;
};

// To get newest Questions
export const getNewestQuestion = (qlist: Question[]): Question[] => {
    return qlist.sort((a, b) => {
        if (a.ask_date_time > b.ask_date_time) {
            return -1;
        } else if (a.ask_date_time < b.ask_date_time) {
            return 1;
        } else {
            return 0;
        }
    });
};

// To get Unanswered Questions
export const getUnansweredQuestion = (qlist: Question[]): Question[] => {
    return getNewestQuestion(qlist).filter((q) => q.answers.length === 0);
};

// To get Active Questions
export const getActiveQuestion = (qlist: Question[]): Question[] => {
    const mp = new Map();
    qlist.forEach((q) => {
        getMostRecentAnswerTime(q, mp);
    });

    return getNewestQuestion(qlist).sort((a, b) => {
        const adate = mp.get(a._id?.toString());
        const bdate = mp.get(b._id?.toString());
        if (!adate) {
            return 1;
        } else if (!bdate) {
            return -1;
        }
        if (adate > bdate) {
            return -1;
        } else if (adate < bdate) {
            return 1;
        } else {
            return 0;
        }
    });
};

export const addTag = async (tag: Tag): Promise<Tag | null> => {

    try {
        // Check if a tag with the given name already exists
        const existingTag = await TagModel.findOne({ name: tag.name });
        if (existingTag) {
            return existingTag as Tag;
        } 

        // If the tag does not exist, create a new one
        const newTag = new TagModel(tag);
        const savedTag = await newTag.save();
        return savedTag as Tag;

    } catch (error) {
        console.error("Error adding tag:", error);
        return null;
    }
};


export const getMostRecentAnswerTime = (q: Question, mp: Map<string, Date>): void => {
    q.answers.forEach((a: Answer) => {
        if (q._id !== undefined) {
            const currentMostRecent = mp.get(q?._id.toString());
        if (!currentMostRecent || currentMostRecent < a.ans_date_time) {
            mp.set(q._id.toString(), a.ans_date_time);
        }
        }
    });
};


export const getQuestionsByOrder = async (order: OrderType): Promise<Question[]> => {
    try {
        let qlist = [];
        if (order == "active") {
            qlist = await QuestionModel.find().populate([
                { path: "tags", model: TagModel },
                { path: "answers", model: AnswerModel },
            ]);
            return getActiveQuestion(qlist);
        } else {
            qlist = await QuestionModel.find().populate([{ path: "tags", model: TagModel }]);
            if (order == "unanswered") {
                return getUnansweredQuestion(qlist);
            } else {
                return getNewestQuestion(qlist);
            }
        }
    }
    catch (error) {
        return [];
    }
};


export const filterQuestionsBySearch = (qlist: Question[], search: string): Question[] => {
    const searchTags = parseTags(search);
    const searchKeyword = parseKeyword(search);
    
    if (!qlist || qlist.length == 0) {
        return [];
    }
    return qlist.filter((q: Question) => {
        if (searchKeyword.length == 0 && searchTags.length == 0) {
            return true;
        } else if (searchKeyword.length == 0) {
            return checkTagInQuestion(q, searchTags);
        } else if (searchTags.length == 0) {
            return checkKeywordInQuestion(q, searchKeyword);
        } else {
            return (
                checkKeywordInQuestion(q, searchKeyword) ||
                checkTagInQuestion(q, searchTags)
            );
        }
    });
};

export const fetchAndIncrementQuestionViewsById = async (qid: string): Promise<QuestionResponse | null> => {
    try {
        const q = await QuestionModel.findOneAndUpdate(
            { _id: new ObjectId(qid) },
            { $inc: { views: 1 } },
            { new: true }
        ).populate({ path: 'answers', model: AnswerModel });
        return q;
    }
    catch (error) {
        return { error: "Error when fetching and updating a question" };
    }
};

export const saveQuestion = async (q: Question): Promise<QuestionResponse> => {
    try {
        const result = await QuestionModel.create(q);
        return result;
    }
    catch (error) {
        return { error: "Error when saving a question" };
    }
};

export const saveAnswer = async (a: Answer): Promise<AnswerResponse> => {
    try {
        const result = await AnswerModel.create(a);
        return result;
    }
    catch (error) {
        return { error: "Error when saving an answer" };
    }
};

export const getTags = async (tags: Tag[]): Promise<Tag[]> => {
    try {
        return await Promise.all(
            tags.map(async function(tag) {
                const addedTag = await addTag(tag);

                if (addedTag) {
                    return addedTag;
                } else {
                    throw new Error("Error while adding tag");
                }
            })
        );
    } catch (error) {
        // Log the error for debugging purposes
        console.error('An error occurred while adding tags:', error);
        return [];
    }
};

/**
 * Implement the below two functions to handle upvoting and downvoting of questions. These functions will:
 *
 * - Check if the question exists.
 * - Add or remove the user's vote (upvote or downvote) as appropriate.
 * - Update the question’s upvote and downvote counts.
 */

export const addUpvoteToQuestion = async (qid: string, username: string) => {
    // TODO: Implement function
};

export const addDownvoteToQuestion = async (qid: string, username: string) => {
    // TODO: Implement function
};

export const addAnswerToQuestion = async (qid: string, ans: Answer): Promise<QuestionResponse | null> => {
    try {
        if(!ans || !ans.text || !ans.ans_by || !ans.ans_date_time) {
            throw new Error("Invalid answer");
        }
        const result = await QuestionModel.findOneAndUpdate(
            { _id: qid },
            { $push: { answers: { $each: [ans._id], $position: 0 } } },
            { new: true }
        );
        return result;
    }
    catch (error) {
        return { error: "Error when adding answer to question" };
    }
};

export const getTagCountMap = async (): Promise<Map<string, number> | null | { error: string }> => {
    try {
        const tlist = await TagModel.find();
        const qlist = await QuestionModel.find().populate({ path: "tags", model: TagModel });
        if(!tlist || tlist.length === 0) {
            return null;
        }
        const tmap = new Map(tlist.map((t) => [t.name, 0]));
        if(qlist != null && qlist != undefined && qlist.length > 0) {
            qlist.map((q) => {
                q.tags.map((t) => {
                    tmap.set(t.name, (tmap.get(t.name) || 0) + 1);
                });
            });
        }
        return tmap;
    }
    catch (error) {
        return {error: "Error when construction tag map"};     
    }
};