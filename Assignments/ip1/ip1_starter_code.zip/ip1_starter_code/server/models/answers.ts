import answerSchema from "./schema/answer";
import { Answer } from "../types";
import mongoose, { Model } from "mongoose";

const AnswerModel: Model<Answer> = mongoose.model<Answer>('Answer', answerSchema);

export default AnswerModel;