import mongoose, { Model } from "mongoose";
import tagSchema from "./schema/tag";
import { Tag } from "../types";

const TagModel: Model<Tag> = mongoose.model<Tag>('Tag', tagSchema);

export default TagModel;