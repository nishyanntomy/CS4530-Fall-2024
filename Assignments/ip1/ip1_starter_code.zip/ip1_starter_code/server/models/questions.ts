// Question Document Schema
import questionSchema from "./schema/question";
import { Question } from "../types";
import mongoose, { Model } from "mongoose";

const QuestionModel: Model<Question> = mongoose.model<Question>('Question', questionSchema);

export default QuestionModel;